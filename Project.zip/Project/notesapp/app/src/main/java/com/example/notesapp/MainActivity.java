// MainActivity.java
package com.example.notesapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText noteEditText;
    private Button addButton, updateButton, deleteButton;
    private ListView notesListView;
    private ArrayList<String> notesList;
    private ArrayAdapter<String> adapter;
    private DatabaseHelper dbHelper;
    private int selectedNoteId = -1;
    private String selectedNoteContent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupDatabase();
        setupListView();
        setupButtonListeners();
        loadNotes();
    }

    private void initializeViews() {
        noteEditText = findViewById(R.id.noteEditText);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        notesListView = findViewById(R.id.notesListView);
        notesList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notesList);
        notesListView.setAdapter(adapter);
    }

    private void setupDatabase() {
        dbHelper = new DatabaseHelper(this);
    }

    private void setupListView() {
        notesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedNoteId = position + 1;
                selectedNoteContent = notesList.get(position);
                noteEditText.setText(selectedNoteContent);
            }
        });

        notesListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showDeleteConfirmation(position + 1);
                return true;
            }
        });
    }

    private void setupButtonListeners() {
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewNote();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateSelectedNote();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelectedNote();
            }
        });
    }

    private void addNewNote() {
        String noteContent = noteEditText.getText().toString().trim();
        if (!noteContent.isEmpty()) {
            dbHelper.addNote(noteContent);
            noteEditText.setText("");
            loadNotes();
            Toast.makeText(MainActivity.this, "Note added successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Please enter note content", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSelectedNote() {
        if (selectedNoteId != -1) {
            String updatedContent = noteEditText.getText().toString().trim();
            if (!updatedContent.isEmpty()) {
                dbHelper.updateNote(selectedNoteId, updatedContent);
                loadNotes();
                Toast.makeText(MainActivity.this, "Note updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Please enter note content", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please select a note to update", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteSelectedNote() {
        if (selectedNoteId != -1) {
            showDeleteConfirmation(selectedNoteId);
        } else {
            Toast.makeText(MainActivity.this, "Please select a note to delete", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDeleteConfirmation(final int noteId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Note")
                .setMessage("Are you sure you want to delete this note?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper.deleteNote(noteId);
                        loadNotes();
                        noteEditText.setText("");
                        selectedNoteId = -1;
                        Toast.makeText(MainActivity.this, "Note deleted successfully", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadNotes() {
        notesList.clear();
        Cursor cursor = dbHelper.getAllNotes();
        while (cursor.moveToNext()) {
            notesList.add(cursor.getString(1));
        }
        adapter.notifyDataSetChanged();
        cursor.close();
    }

    // DatabaseHelper Class (Inner Class)
    public static class DatabaseHelper extends android.database.sqlite.SQLiteOpenHelper {
        private static final String DATABASE_NAME = "NotesDB";
        private static final int DATABASE_VERSION = 1;
        private static final String TABLE_NOTES = "notes";
        private static final String COLUMN_ID = "id";
        private static final String COLUMN_CONTENT = "content";

        public DatabaseHelper(android.content.Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String createTable = "CREATE TABLE " + TABLE_NOTES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_CONTENT + " TEXT)";
            db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
            onCreate(db);
        }

        public void addNote(String content) {
            SQLiteDatabase db = this.getWritableDatabase();
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(COLUMN_CONTENT, content);
            db.insert(TABLE_NOTES, null, values);
            db.close();
        }

        public Cursor getAllNotes() {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.rawQuery("SELECT * FROM " + TABLE_NOTES, null);
        }

        public void updateNote(int id, String content) {
            SQLiteDatabase db = this.getWritableDatabase();
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(COLUMN_CONTENT, content);
            db.update(TABLE_NOTES, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
            db.close();
        }

        public void deleteNote(int id) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(TABLE_NOTES, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
            db.close();
        }
    }
}